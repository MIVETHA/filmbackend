package com.example.filmrental.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import com.example.filmrental.model.Country;
import com.example.filmrental.model.Language;
import com.example.filmrental.service.CountryService;
import com.example.filmrental.service.LanguageService;
@RestController
@RequestMapping("/api/languages")
public class LanguageController {
	@Autowired
	private LanguageService languageservice;
	
	@GetMapping
	public ResponseEntity<List<Language>> getAllLanguages() {
		List<Language> languages = languageservice.getAllLanguages();
		return ResponseEntity.ok(languages);
	}
	
	@PostMapping("/post")
	public ResponseEntity<String> createlanguage(@RequestBody Language lang) {

		languageservice.createlanguage(lang);

		return new ResponseEntity<>("Record Created Successfully", HttpStatus.CREATED);

	}

}
