package com.example.filmrental.service;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
 
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.filmrental.dto.ActorDto;
import com.example.filmrental.dto.FilmDto;
import com.example.filmrental.exception.InvalidInputException;
import com.example.filmrental.exception.ResourceNotFoundException;
import com.example.filmrental.model.Actor;
import com.example.filmrental.model.Category;
import com.example.filmrental.model.Film;
import com.example.filmrental.model.FilmActor;
import com.example.filmrental.model.FilmCategory;
import com.example.filmrental.model.Language;
import com.example.filmrental.repository.ActorRepository;
import com.example.filmrental.repository.CategoryRepository;
import com.example.filmrental.repository.FilmActorRepository;
import com.example.filmrental.repository.FilmCategoryRepository;
import com.example.filmrental.repository.FilmRepository;

import jakarta.transaction.Transactional;
 
@Service
public class FilmService  {
 
	@Autowired
	private FilmRepository filmRepository;
 
	@Autowired
	private ModelMapper modelMapper;
 
 
	@Autowired
	private FilmActorRepository filmActorRepository;
 
 
	@Autowired
	private ActorRepository actorRepository;
 
	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private FilmCategoryRepository filmCategoryRepository;
	
	@Autowired
	private FilmCategoryRepository filmCategoryRepository;
	
	@Transactional
	public FilmDto addFilm(FilmDto filmDTO) {
		Film film = modelMapper.map(filmDTO, Film.class);
		Film saved = filmRepository.save(film);
		return modelMapper.map(saved, FilmDto.class);
	}
	public FilmDto findFilmsByTitle(String title) {
		List<Film> film = filmRepository.findFilmByTitle(title);
		return film != null ? modelMapper.map(film, FilmDto.class) : null;
	}
 
	public List<FilmDto> getAllFilm() {
		List<Film> films = filmRepository.findAll();

		films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList()).forEach(System.out::println);

		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
	}

	public Page<FilmDto> getAllFilmsWithFilters(
			String title, Integer actorId, Integer categoryId, Long languageId,
			String rating, Integer releaseYear, Double minPrice, Double maxPrice,
			Pageable pageable) {
		
		// Get all films first (we'll filter in memory for now)
		// In production, use Specification or custom query for better performance
		List<Film> allFilms = filmRepository.findAll();
		
		// Apply filters
		List<Film> filteredFilms = allFilms.stream()
			.filter(film -> title == null || film.getTitle().toLowerCase().contains(title.toLowerCase()))
			.filter(film -> languageId == null || (film.getLanguage() != null && film.getLanguage().getLanguageId().equals(languageId)))
			.filter(film -> releaseYear == null || (film.getReleaseYear() != null && film.getReleaseYear().equals(releaseYear)))
			.filter(film -> rating == null || (film.getRating() != null && film.getRating().toString().equals(rating)))
			.filter(film -> minPrice == null || (film.getRentalRate() >= minPrice.doubleValue()))
			.filter(film -> maxPrice == null || (film.getRentalRate() <= maxPrice.doubleValue()))
			.collect(Collectors.toList());
		
		// Filter by actorId if provided
		if (actorId != null) {
			List<FilmActor> filmActors = filmActorRepository.findAll();
			List<Integer> filmIdsWithActor = filmActors.stream()
				.filter(fa -> fa.getActor().getId().equals(actorId))
				.map(fa -> fa.getFilm().getFilmId())
				.distinct()
				.collect(Collectors.toList());
			
			filteredFilms = filteredFilms.stream()
				.filter(film -> filmIdsWithActor.contains(film.getFilmId()))
				.collect(Collectors.toList());
		}
		
		// Filter by categoryId if provided
		if (categoryId != null) {
			List<FilmCategory> filmCategories = filmCategoryRepository.findAll();
			List<Integer> filmIdsWithCategory = filmCategories.stream()
				.filter(fc -> fc.getCategory().getCategoryId().equals(categoryId))
				.map(fc -> fc.getFilm().getFilmId())
				.distinct()
				.collect(Collectors.toList());
			
			filteredFilms = filteredFilms.stream()
				.filter(film -> filmIdsWithCategory.contains(film.getFilmId()))
				.collect(Collectors.toList());
		}
		
		// Convert to DTOs
		List<FilmDto> filmDtos = filteredFilms.stream()
			.map(film -> modelMapper.map(film, FilmDto.class))
			.collect(Collectors.toList());
		
		// Apply pagination manually
		int start = (int) pageable.getOffset();
		int end = Math.min((start + pageable.getPageSize()), filmDtos.size());
		List<FilmDto> pageContent = start < filmDtos.size() ? filmDtos.subList(start, end) : new java.util.ArrayList<>();
		
		// Create Page object
		Page<FilmDto> page = new org.springframework.data.domain.PageImpl<>(
			pageContent, pageable, filmDtos.size());
		
		return page;
	}
 
	public FilmDto getFilmById(Integer id) {
		Optional<Film> film = filmRepository.findById(id);
		if (film.isPresent()) {
			return modelMapper.map(film.get(), FilmDto.class);
		}
		return null;
	}

	public List<FilmDto> findFilmsByReleaseYear(int releaseYear) {
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getReleaseYear() == releaseYear)
				.collect(Collectors.toList());
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
	}
 
	public List<FilmDto> findFilmsByRentalDuration(int rd) {
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getRentalDuration() > rd)
				.collect(Collectors.toList());
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
	}
 
	public List<FilmDto> findFilmsWhereRentalRateIsGreater(int rate) {
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getRentalRate() > rate)
				.collect(Collectors.toList());
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
	}
 
	public List<FilmDto> findFilmsWhereLengthIsGreater(int length) {
		// TODO Auto-generated method stub
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getLength()>length)
				.collect(Collectors.toList());
 
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
	}
	
	public List<FilmDto> findFilmsWhereRentalDurationIsLower(int rd) {
		// TODO Auto-generated method stub
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getRentalDuration() < rd)
				.collect(Collectors.toList());
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
 
	}
 
 
	public List<FilmDto> findFilmsWhereRateIsLower(int rate) {
		// TODO Auto-generated method stub
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getRentalRate() < rate)
				.collect(Collectors.toList());
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
	}
 
	public List<FilmDto> findFilmsWhereLengthIsLower(int length) {
		// TODO Auto-generated method stub
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getLength()<length)
				.collect(Collectors.toList());
 
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
 
	}
 
	
	public List<FilmDto> findFilmBetweenYear(int from, int to) {
		// TODO Auto-generated method stub
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getReleaseYear()>from && film.getReleaseYear()<to)
				.collect(Collectors.toList());
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
	}
 
	
	public List<FilmDto> findFilmsWhereRatingIsLower(int rating) {
		// TODO Auto-generated method stub
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getRating() < rating)
				.collect(Collectors.toList());
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
	}
 
	
	public List<FilmDto> findFilmsWhereRatingIsHigher(int rating) {
		// TODO Auto-generated method stub
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getRating()>rating)
				.collect(Collectors.toList());
		return films.stream().map(film -> modelMapper.map(film, FilmDto.class)).collect(Collectors.toList());
 
 
	}
 
	
	public List<FilmDto> findFilmsByLanguage(String lang) {
		// TODO Auto-generated method stub
 
		if (lang == null || lang.trim().isEmpty()) {
			throw new IllegalArgumentException("Language cannot be null or empty");
		}
 
		List<Film> films = filmRepository.findAll().stream()
				.filter(film -> film.getLanguage() != null && film.getLanguage().getName().equals(lang))
				.collect(Collectors.toList());
 
		return films.stream()
				.map(film -> modelMapper.map(film, FilmDto.class))
				.collect(Collectors.toList());
	}
 
	public Map<Integer, Integer> displayFilmsNumberByYear() {
		// TODO Auto-generated method stub
		Map<Integer,Integer> filmCountByYear= new HashMap<>();
		for(int i=1900; i<=2100;i++ ) {
			filmCountByYear.put(i, 0);
		}
 
		List<Film> films = filmRepository.findAll();
 
		for (Film film : films) {
			Integer releaseYear = film.getReleaseYear();
			if (releaseYear != null && releaseYear >= 1900 && releaseYear <= 2100) {
				filmCountByYear.put(releaseYear, filmCountByYear.get(releaseYear) + 1);
			}
		}
 
		return filmCountByYear;
	}
 
	
	public FilmDto updateTitle(Integer id, String title) throws InvalidInputException {
		Film film = filmRepository.findById(id)
				.orElseThrow(() -> new InvalidInputException("Film with ID " + id + " not found"));
 
		if (title == null || title.trim().isEmpty()) {
			throw new InvalidInputException("New title cannot be null or empty");
		}
 
		film.setTitle(title);
 
		Film updatedFilm = filmRepository.save(film);
 
		return modelMapper.map(updatedFilm, FilmDto.class);
	}
 
	
	public FilmDto updateReleaseYear(Integer id,int year) throws InvalidInputException {
		// TODO Auto-generated method stub
		Film film = filmRepository.findById(id)
				.orElseThrow(() -> new InvalidInputException("Film with ID " + id + " not found"));
 
		film.setReleaseYear(year);
 
		Film updatedFilm = filmRepository.save(film);
 
 
		return modelMapper.map(updatedFilm, FilmDto.class);
	}
 
	
	public FilmDto updateRentalDuration(Integer id, int rental_duration) throws InvalidInputException {
		// TODO Auto-generated method stub
		Film film = filmRepository.findById(id)
				.orElseThrow(() -> new InvalidInputException("Film with ID " + id + " not found"));
		film.setRentalDuration(rental_duration);
		Film updatedFilm = filmRepository.save(film);
 
		return modelMapper.map(updatedFilm, FilmDto.class);
	}
 
	public FilmDto updateRentalRate(Integer id, int rental_rate) throws InvalidInputException {
		// TODO Auto-generated method stub
		Film film = filmRepository.findById(id)
				.orElseThrow(() -> new InvalidInputException("Film with ID " + id + " not found"));
		film.setRentalRate(rental_rate);
		Film updatedFilm = filmRepository.save(film);
 
		return modelMapper.map(updatedFilm, FilmDto.class);
	}
 
	public FilmDto updateRating(Integer id, int rating) throws InvalidInputException {
		// TODO Auto-generated method stub
		Optional<Film> film = Optional.of(filmRepository.findById(id)
				.orElseThrow(() -> new InvalidInputException("Film with ID " + id + " not found")));
 
		film.get().setRating(rating);
		Film updatedFilm = filmRepository.save(film.get());
		return modelMapper.map(updatedFilm, FilmDto.class);
	}
 
	public FilmDto updateLanguage(Integer id, Integer lang_id) throws InvalidInputException {
		// TODO Auto-generated method stub
		Film film = filmRepository.findById(id)
				.orElseThrow(() -> new InvalidInputException("Film with ID " + id + " not found"));
		film.getLanguage().setLanguageId(lang_id);
		Film updatedFilm = filmRepository.save(film);
		return modelMapper.map(updatedFilm, FilmDto.class);
	}
 
	@Transactional
	public void assignActorsToFilm(Integer filmId, Collection<Integer> actorIds) {
 
		Film film = filmRepository.findById(filmId)
				.orElseThrow(() -> new IllegalArgumentException("Film with ID " + filmId + " not found"));
 
		for (Integer actorId : actorIds) {
			Actor actor = actorRepository.findById(actorId)
					.orElseThrow(() -> new IllegalArgumentException("Actor with ID " + actorId + " not found"));
 
			// Check if the association already exists
			if (!filmActorRepository.existsByFilmAndActor(film, actor)) {
				FilmActor filmActor = new FilmActor();
				filmActor.setFilm(film);
				filmActor.setActor(actor);
				filmActor.setLastUpdate(Instant.now());
 
				filmActorRepository.save(filmActor);
			}
		}
	}
 
	
	public FilmCategory updateCategory(Integer id, Integer category_id) throws InvalidInputException {
		Optional<Film> film = filmRepository.findById(id);
        Optional<Category> category = categoryRepository.findById(category_id);
      	FilmCategory filmCategory = new FilmCategory();
		if(!filmCategoryRepository.existsByFilmAndCategory(film,category)) {
 
			filmCategory.setFilm(film.get());
			filmCategory.setCategory(category.get());
			filmCategoryRepository.save(filmCategory);
 
		}
		return filmCategory;
	}
	@Transactional
	public List<ActorDto> getActorsOfFilm(Integer filmId) throws InvalidInputException {
	    Film film = filmRepository.findById(filmId)
	            .orElseThrow(() -> new InvalidInputException("Film with ID " + filmId + " not found"));

	    return filmActorRepository.findActorsByFilmId(film.getFilmId())
	            .stream()
	            .map(a -> modelMapper.map(a, ActorDto.class))
	            .collect(Collectors.toList());
	}

	@Transactional
	public List<FilmDto> findFilmsByCategory(String categoryName) throws InvalidInputException {
	    if (categoryName == null || categoryName.trim().isEmpty()) {
	        throw new InvalidInputException("Category must not be empty");
	    }
	    return filmCategoryRepository.findFilmsByCategoryName(categoryName.trim())
	            .stream()
	            .map(f -> modelMapper.map(f, FilmDto.class))
	            .collect(Collectors.toList());
	}

	public FilmDto updateFilm(Integer id, FilmDto filmDTO) throws ResourceNotFoundException, InvalidInputException {
		Film film = filmRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Film with ID " + id + " not found"));
		
		// Update film fields from DTO
		if (filmDTO.getTitle() != null) film.setTitle(filmDTO.getTitle());
		if (filmDTO.getDescription() != null) film.setDescription(filmDTO.getDescription());
		if (filmDTO.getReleaseYear() != null) film.setReleaseYear(filmDTO.getReleaseYear());
		if (filmDTO.getLanguageId() != null) {
			Language language = new Language();
			language.setLanguageId(filmDTO.getLanguageId());
			film.setLanguage(language);
		}
		if (filmDTO.getRentalDuration() != null) film.setRentalDuration(filmDTO.getRentalDuration());
		if (filmDTO.getRentalRate() != null) film.setRentalRate(filmDTO.getRentalRate().intValue());
		if (filmDTO.getLength() != null) film.setLength(filmDTO.getLength());
		if (filmDTO.getReplacementCost() != null) film.setReplacementCost(filmDTO.getReplacementCost());
		if (filmDTO.getRating() != null) film.setRating(filmDTO.getRating());
		if (filmDTO.getSpecialFeatures() != null) film.setSpecialFeatures(filmDTO.getSpecialFeatures());
		
		Film updated = filmRepository.save(film);
		return modelMapper.map(updated, FilmDto.class);
	}

	public void deleteFilm(Integer id) throws ResourceNotFoundException {
		Film film = filmRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Film with ID " + id + " not found"));
		filmRepository.delete(film);
	}

}
 
 
 
 
 
 
 