package com.example.filmrental.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.filmrental.dto.LoginRequest;
import com.example.filmrental.dto.LoginResponse;
import com.example.filmrental.exception.ResourceNotFoundException;
import com.example.filmrental.model.Customer;
import com.example.filmrental.model.Staff;
import com.example.filmrental.repository.CustomerRepository;
import com.example.filmrental.repository.StaffRepository;

@Service
public class AuthService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private StaffRepository staffRepository;

    public LoginResponse login(LoginRequest request) throws ResourceNotFoundException {
        String email = request.getEmail();
        String password = request.getPassword();

        // First check if it's a Staff member (has password)
        List<Staff> staffList = staffRepository.findOneByEmail(email);
        if (!staffList.isEmpty()) {
            Staff staff = staffList.get(0);
            // Validate password (simple comparison - in production, use password hashing)
            if (password != null && password.equals(staff.getPassword())) {
                String token = generateToken();
                return new LoginResponse(token, "STAFF", staff.getStaffId(), staff.getEmail());
            } else {
                throw new ResourceNotFoundException("Invalid credentials");
            }
        }

        // Check if it's a Customer (no password required for now)
        List<Customer> customerList = customerRepository.findByEmail(email);
        if (!customerList.isEmpty()) {
            Customer customer = customerList.get(0);
            // For customers, we'll accept login without password check for now
            // In production, add password field to Customer model
            String token = generateToken();
            return new LoginResponse(token, "CUSTOMER", customer.getCustomerId(), customer.getEmail());
        }

        throw new ResourceNotFoundException("User not found with email: " + email);
    }

    private String generateToken() {
        // Simple token generation - in production, use JWT
        return "token_" + UUID.randomUUID().toString();
    }
}

