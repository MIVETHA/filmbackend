package com.example.filmrental.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.filmrental.model.Category;
import com.example.filmrental.repository.CategoryRepository;


@Service
public class CategoryService 
{
	@Autowired
	private CategoryRepository categoryrepo;
	
	public List<Category> getAllCategories() {
		return categoryrepo.findAll();
	}
	
	public Category createcategory(Category category) {
        Category savedcategory = categoryrepo.save(category);
        return savedcategory;

    }


}
