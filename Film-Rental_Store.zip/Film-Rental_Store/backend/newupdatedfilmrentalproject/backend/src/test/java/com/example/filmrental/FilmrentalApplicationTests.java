package com.example.filmrental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmrentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
